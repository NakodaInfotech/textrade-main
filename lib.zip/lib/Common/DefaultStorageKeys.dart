const userId = "userId";
const compId = "compId";
const selectedDate = "selectedDate";
const baseUrlVal = "baseUrlValue";
