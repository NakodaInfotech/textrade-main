class SearchGenericModel {
  String? name;
  String? id;
  bool? isSelected;

  SearchGenericModel(String? name, String? id, {bool? isSelected}) {
    this.name = name;
    this.id = id;
    this.isSelected = isSelected;
  }
}
